package com.example.learngerman.utils

class EventbusDataEvents {
    internal class PhonenumberSend(var Phonenumber:String)
}