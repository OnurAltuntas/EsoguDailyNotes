package com.example.learngerman.Login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.learngerman.MainActivity
import com.example.learngerman.R
import com.example.learngerman.utils.EventbusDataEvents
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_register.*
import org.greenrobot.eventbus.EventBus

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)



        btnRegisterNext.setOnClickListener {


            if(edittxtEmail.text.isNotEmpty() && edittxtPassword.text.isNotEmpty()){

                yeniUyeKayit(edittxtEmail.text.toString(),edittxtPassword.text.toString())
            }else{
                Toast.makeText(this,"Boş alanları doldurunuz",Toast.LENGTH_SHORT).show()
            }


        }


    }

    private fun yeniUyeKayit(mail: String, şifre: String) {
        progressBarGoster()

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(mail,şifre)
            .addOnCompleteListener(object : OnCompleteListener<AuthResult> {
                override fun onComplete(p0: Task<AuthResult>) {

                    if(p0.isSuccessful){
                        progressBarGizle()
                        Toast.makeText(this@RegisterActivity,"Üye kaydedildi",Toast.LENGTH_SHORT).show()
                        FirebaseAuth.getInstance().signOut()
//                        var intent = Intent(this@RegisterActivity, MainActivity::class.java)
//                        startActivity(intent)
                    }else{
                        progressBarGizle()
                        Toast.makeText(this@RegisterActivity,"Üye kaydedilemedi :"+p0.exception,Toast.LENGTH_SHORT).show()
                    }
                }
            })
    }

    private fun progressBarGoster(){
        progressBar.visibility=View.VISIBLE
    }
    private fun progressBarGizle(){
        progressBar.visibility=View.INVISIBLE

    }

    private fun onayMailiGonder(){
        var kullanici=FirebaseAuth.getInstance().currentUser
        if(kullanici!=null){
            kullanici.sendEmailVerification()
                .addOnCompleteListener(object:OnCompleteListener<Void>{
                    override fun onComplete(p0: Task<Void>) {
                        if(p0.isSuccessful){
                            Toast.makeText(this@RegisterActivity,"Mail atıldı onaylayın :",Toast.LENGTH_SHORT).show()
                        }else{
                            Toast.makeText(this@RegisterActivity,"Mail atılamadı:",Toast.LENGTH_SHORT).show()
                        }
                    }

                })
        }
    }


}
